/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import Database.Koneksi;
import java.sql.SQLException;

/**
 *
 * @author FLOW
 */
public class UserModel extends Koneksi{
    protected String idUser;
    protected String nama;
    protected String noTelepon;
    protected String password;
    protected String role;
    protected String jabatan;
//    protected String nim;
    protected String programStudi;
    protected String fakultas;

    public String getIdUser() {
        return idUser;
    }


    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getNoTelepon() {
        return noTelepon;
    }

    public void setNoTelepon(String noTelepon) {
        this.noTelepon = noTelepon;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getJabatan() {
        return jabatan;
    }

    public void setJabatan(String jabatan) {
        this.jabatan = jabatan;
    }

    public String getProgramStudi() {
        return programStudi;
    }

    public String getFakultas() {
        return fakultas;
    }
    
    public boolean authenticateUser(String username, String password, String role) {
        boolean isOperationSuccess = false;

        try {
            openConnection();

            String query = "SELECT * FROM user WHERE id_user = ? AND password = ? AND role = ?";
            
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);
            preparedStatement.setString(3, role);

            resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                this.idUser = resultSet.getString("id_user");
                this.password = resultSet.getString("password");
                this.role = resultSet.getString("role");
                
                isOperationSuccess = true;
                
            }
        } catch (SQLException ex) {
            this.displayErrors((SQLException) ex);
        } finally {
            closeConnection();
        }

        return isOperationSuccess;
    }
    
    public boolean findDataUserStaff(String username) {
        boolean isOperationSuccess = false;

        try {
            openConnection();

            String query = "SELECT u.*, s.* FROM user u JOIN staff s ON u.id_user = s.id_user WHERE u.id_user = ?";

            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, username);

            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                this.idUser = resultSet.getString("id_user");
                this.jabatan = resultSet.getString("jabatan");
                this.nama = resultSet.getString("nama");
                this.noTelepon = resultSet.getString("no_telepon");

                isOperationSuccess = true;
            }
        } catch (SQLException ex) {
            this.displayErrors(ex);
        } finally {
            closeConnection();
        }

        return isOperationSuccess;
    }
    
    public boolean findMahasiswa(String nim) {
        boolean isOperationSuccess = false;

        try {
            openConnection();

            String query = "SELECT u.*, m.* FROM user u JOIN mahasiswa m ON u.id_user = m.id_user WHERE m.id_user = ?";
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, nim);
            resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                this.idUser = resultSet.getString("id_user");
                this.nama = resultSet.getString("nama");
                this.programStudi = resultSet.getString("program_studi");
                this.fakultas = resultSet.getString("fakultas");
                this.noTelepon = resultSet.getString("no_telepon");

                isOperationSuccess = true; // Update the variable here
            }
        } catch (SQLException ex) {
            this.displayErrors(ex);
        } finally {
            closeConnection();
        }
        return isOperationSuccess;
    }
}