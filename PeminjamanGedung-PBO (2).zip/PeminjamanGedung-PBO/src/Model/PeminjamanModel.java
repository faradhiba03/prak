/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import Database.Koneksi;
import java.sql.SQLException;
import java.util.Date;
import javax.swing.table.DefaultTableModel;
import java.sql.ResultSet;

/**
 *
 * @author FLOW
 */
public class PeminjamanModel extends Koneksi {
    private int idPeminjaman;
    private Date tanggalPeminjaman;
    private Date tanggalSelesai;
    private String keperluan;
    private String status;
    private int idGedung;
    private String idMahasiswa;
    private String idStaff;
    private String nim;
    private String namaGedung;

    public int getIdPeminjaman() {
        return idPeminjaman;
    }
 
    public boolean createPeminjaman(java.sql.Date tanggalPeminjaman, java.sql.Date tanggalSelesai, String keperluan, String status, int gedungId, String staffUserId, String mahasiswaId) {
        boolean isOperationSuccess = false;

        try {
            openConnection();

            // Check if there is any overlapping reservation for the specified building
            if (!isBuildingAvailable(gedungId, tanggalPeminjaman, tanggalSelesai)) {
                System.out.println("Building is not available for the specified period.");
                return false;
            }

            String query = "INSERT INTO peminjaman (tanggal_peminjaman, tanggal_selesai, keperluan, status, gedung_id_gedung, staff_id_user, mahasiswa_id_user) VALUES (?, ?, ?, ?, ?, ?, ?)";

            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setDate(1, tanggalPeminjaman);
            preparedStatement.setDate(2, tanggalSelesai);
            preparedStatement.setString(3, keperluan);
            preparedStatement.setString(4, status);
            preparedStatement.setInt(5, gedungId);
            preparedStatement.setString(6, staffUserId);
            preparedStatement.setString(7, mahasiswaId);

            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                this.tanggalPeminjaman = tanggalPeminjaman;
                this.tanggalSelesai = tanggalSelesai;
                this.keperluan = keperluan;
                this.status = status;
                this.idGedung = gedungId;
                this.idStaff = staffUserId;
                this.idMahasiswa = mahasiswaId;

                isOperationSuccess = true;
            } else {
                System.out.println("Insertion failed");
            }
        } catch (SQLException ex) {
            this.displayErrors(ex);
        } finally {
            closeConnection();
        }
        return isOperationSuccess;
    }

    private boolean isBuildingAvailable(int gedungId, java.sql.Date startDate, java.sql.Date endDate) throws SQLException {
        String query = "SELECT * FROM peminjaman WHERE gedung_id_gedung = ? AND status = 'Approved' AND ((tanggal_peminjaman <= ? AND tanggal_selesai >= ?) OR (tanggal_peminjaman <= ? AND tanggal_selesai >= ?))";

        preparedStatement = connection.prepareStatement(query);
        preparedStatement.setInt(1, gedungId);
        preparedStatement.setDate(2, endDate);
        preparedStatement.setDate(3, startDate);
        preparedStatement.setDate(4, startDate);
        preparedStatement.setDate(5, endDate);

        ResultSet resultSet = preparedStatement.executeQuery();

        return !resultSet.next();
    }
    
    public boolean updatePeminjaman(String newStatus, int peminjamanId) {
        boolean isOperationSuccess = false;

        try {
            openConnection();

            String query = "UPDATE peminjaman SET status = ? WHERE id_peminjaman = ?";
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, newStatus);
            preparedStatement.setInt(2, peminjamanId);
            
            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                isOperationSuccess = true;
            }

        } catch (SQLException ex) {
            this.displayErrors(ex);
        } finally {
            closeConnection();
        }

        return isOperationSuccess;
    }


    public boolean deletePeminjaman(int peminjamanId) {
        boolean isOperationSuccess = false;

        try {
            openConnection();

            String query = "DELETE FROM peminjaman WHERE id_peminjaman = ?";
            
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, peminjamanId);
            
            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                isOperationSuccess = true;
            } else {
                System.out.println("Deletion failed. No rows affected.");
            }
        } catch (SQLException ex) {
            this.displayErrors(ex);
        } finally {
            closeConnection();
        }

        return isOperationSuccess;
    }  
    
    public void showPeminjaman(DefaultTableModel tableModel) {
        try {
            openConnection();
            
            String query = "SELECT p.*, m.id_user, g.nama FROM peminjaman p JOIN mahasiswa m ON "
                    + "p.mahasiswa_id_user = m.id_user JOIN gedung g ON p.gedung_id_gedung = g.id_gedung "
                    + "WHERE (p.status = 'Pending' OR p.status = 'Rejected')";
            
            preparedStatement = connection.prepareStatement(query);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                this.idPeminjaman = resultSet.getInt("id_peminjaman");
                this.nim = resultSet.getString("id_user");
                this.namaGedung = resultSet.getString("nama");
                this.tanggalPeminjaman = resultSet.getDate("tanggal_peminjaman");
                this.tanggalSelesai = resultSet.getDate("tanggal_selesai");
                this.keperluan = resultSet.getString("keperluan");
                this.status = resultSet.getString("status");

                Object[] rowData = {idPeminjaman, nim, namaGedung, tanggalPeminjaman, tanggalSelesai, keperluan, status};
                tableModel.addRow(rowData);
            }
        } catch (SQLException ex) {
            this.displayErrors((SQLException) ex);
        } finally {
            closeConnection();
        }
    }
    
    public void showHistory(DefaultTableModel tableModel) {
        try {
            openConnection();
            
            String query = "SELECT p.*, m.id_user, g.nama FROM peminjaman p JOIN mahasiswa m ON "
                    + "p.mahasiswa_id_user = m.id_user JOIN gedung g ON p.gedung_id_gedung = g.id_gedung WHERE"
                    + "(p.status = 'Done' OR p.status = 'Approved')";
            
            preparedStatement = connection.prepareStatement(query);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                this.idPeminjaman = resultSet.getInt("id_peminjaman");
                this.nim = resultSet.getString("id_user");
                this.namaGedung = resultSet.getString("nama");
                this.tanggalPeminjaman = resultSet.getDate("tanggal_peminjaman");
                this.tanggalSelesai = resultSet.getDate("tanggal_selesai");
                this.keperluan = resultSet.getString("keperluan");
                this.status = resultSet.getString("status");

                Object[] rowData = {idPeminjaman, nim, namaGedung, tanggalPeminjaman, tanggalSelesai, keperluan, status};
                tableModel.addRow(rowData);
            }
        } catch (SQLException ex) {
            this.displayErrors((SQLException) ex);
        } finally {
            closeConnection();
        }
    }
    
    public void showPeminjamanMahasiswa(DefaultTableModel tableModel, String idUser) {
        try {
            openConnection();
            
            String query = "SELECT p.*, m.id_user, g.nama FROM peminjaman p JOIN mahasiswa m ON "
                    + "p.mahasiswa_id_user = m.id_user JOIN gedung g ON p.gedung_id_gedung = g.id_gedung "
                    + "WHERE (p.status = 'Pending' OR p.status = 'Rejected') AND m.id_user = ?";
            
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, idUser); 
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                this.idPeminjaman = resultSet.getInt("id_peminjaman");
                this.nim = resultSet.getString("id_user");
                this.namaGedung = resultSet.getString("nama");
                this.tanggalPeminjaman = resultSet.getDate("tanggal_peminjaman");
                this.tanggalSelesai = resultSet.getDate("tanggal_selesai");
                this.keperluan = resultSet.getString("keperluan");
                this.status = resultSet.getString("status");

                Object[] rowData = {idPeminjaman, nim, namaGedung, tanggalPeminjaman, tanggalSelesai, keperluan, status};
                tableModel.addRow(rowData);
            }
        } catch (SQLException ex) {
            this.displayErrors((SQLException) ex);
        } finally {
            closeConnection();
        }
    }
    
    public void showHistoryMahasiswa(DefaultTableModel tableModel, String idUser) {
        try {
            openConnection();
            
            String query = "SELECT p.*, m.id_user, g.nama FROM peminjaman p JOIN mahasiswa m ON "
                    + "p.mahasiswa_id_user = m.id_user JOIN gedung g ON p.gedung_id_gedung = g.id_gedung WHERE"
                    + "(p.status = 'Done' OR p.status = 'Approved') AND m.id_user = ?";
            
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, idUser);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                this.idPeminjaman = resultSet.getInt("id_peminjaman");
                this.nim = resultSet.getString("id_user");
                this.namaGedung = resultSet.getString("nama");
                this.tanggalPeminjaman = resultSet.getDate("tanggal_peminjaman");
                this.tanggalSelesai = resultSet.getDate("tanggal_selesai");
                this.keperluan = resultSet.getString("keperluan");
                this.status = resultSet.getString("status");

                Object[] rowData = {idPeminjaman, nim, namaGedung, tanggalPeminjaman, tanggalSelesai, keperluan, status};
                tableModel.addRow(rowData);
            }
        } catch (SQLException ex) {
            this.displayErrors((SQLException) ex);
        } finally {
            closeConnection();
        }
    }
}
