/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;


/**
 *
 * @author FLOW
 */
public class StaffController extends UserController{
    
    public boolean profileStaff(String username) {
        return userModel.findDataUserStaff(username);
    }
        
    public String getUserJabatan() {
        return userModel.getJabatan();
    }
}
