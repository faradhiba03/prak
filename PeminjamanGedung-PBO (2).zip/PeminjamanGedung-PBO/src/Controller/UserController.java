/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.UserModel;

/**
 *
 * @author FLOW
 */
public class UserController {
    protected final UserModel userModel;
    
    public UserController() {
        this.userModel = new UserModel();
    }

    public boolean loginUser(String username, String password, String role) {
        return userModel.authenticateUser(username, password, role);  
    }   
    
    public String getUserId() {
        return userModel.getIdUser();
    }
    
    public String getUserNama() {
        return userModel.getNama();
    }
    
    public String getUserNoTelepon() {
        return userModel.getNoTelepon();
    }
    
    public boolean getIdMahasiswa(String nim) {
        return userModel.findMahasiswa(nim);
    }   
}
