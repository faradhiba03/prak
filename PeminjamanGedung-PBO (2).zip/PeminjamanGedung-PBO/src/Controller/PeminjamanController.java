/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.PeminjamanModel;
import Model.UserModel;
import java.util.Date;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author FLOW
 */
public class PeminjamanController {
    private final PeminjamanModel peminjaman;
    private UserModel userModel;
    
    public PeminjamanController() {
        this.peminjaman = new PeminjamanModel();
    }
    
    public void showPeminjaman(DefaultTableModel tableModel) {
        peminjaman.showPeminjaman(tableModel);
    }
    
    public void showHistory ( DefaultTableModel tableModel) {
        peminjaman.showHistory(tableModel);
    }
    
    public void showPeminjamanMahasiswa (DefaultTableModel tableModel, String idUser) {
        peminjaman.showPeminjamanMahasiswa(tableModel, idUser);
    }
    
    public void showHistoryMahasiswa ( DefaultTableModel tableModel, String idUser) {
        peminjaman.showHistoryMahasiswa(tableModel, idUser);
    }
    
    public boolean addPeminjaman(Date tanggalPeminjaman, Date tanggalSelesai, String keperluan, String status, int gedungId, String staffUserId, String mahasiswaId) {
        java.sql.Date sqlTanggalPeminjaman = new java.sql.Date(tanggalPeminjaman.getTime());
        java.sql.Date sqlTanggalSelesai = new java.sql.Date(tanggalSelesai.getTime());

        if (!isValidDateRange(sqlTanggalPeminjaman, sqlTanggalSelesai)) {    
        }
        
        boolean success = peminjaman.createPeminjaman(sqlTanggalPeminjaman, sqlTanggalSelesai, keperluan, status, gedungId, mahasiswaId, staffUserId);
        if (success) {
            JOptionPane.showMessageDialog(null, "Peminjaman berhasil ditambahkan", "Sukses", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Penambahan gagal. Silakan coba lagi", "Kesalahan", JOptionPane.ERROR_MESSAGE);
        }

        return success;
    }
        
    private boolean isValidDateRange(java.sql.Date startDate, java.sql.Date endDate) {
        if (startDate.before(new java.sql.Date(System.currentTimeMillis()))) {
            JOptionPane.showMessageDialog(null, "Tanggal Peminjaman tidak boleh kurang dari hari ini");
            return false;
        }

        if (endDate.before(startDate)) {
            JOptionPane.showMessageDialog(null, "Tanggal Selesai tidak boleh kurang dari hari ini");
            return false;
        }

        return true;
    }
    
    public boolean updatePeminjamanStatus(String newStatus, int idPeminjaman) {
        return peminjaman.updatePeminjaman(newStatus, idPeminjaman);
    }
    
    public String getSelectedStatusFromComboBox(JComboBox<String> comboBox) {
        return comboBox.getSelectedItem().toString();
    }
    
    public boolean deletePeminjaman(int peminjamanId) {
        return peminjaman.deletePeminjaman(peminjamanId);
    }
    
    public int getIdPeminjaman(){
        return peminjaman.getIdPeminjaman();
    }   
}
